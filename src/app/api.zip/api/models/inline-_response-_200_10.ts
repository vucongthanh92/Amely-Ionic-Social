/* tslint:disable */

/**
 */
export class inline_response_200_10 {
    group_guid?: number;
}
