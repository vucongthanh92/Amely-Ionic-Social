/* tslint:disable */

/**
 */
export class Options {
}
