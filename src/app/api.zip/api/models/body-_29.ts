/* tslint:disable */

/**
 */
export class body_29 {
    feeds_type?: string;
    owner_guid?: number;
    offset?: number;
    limit?: number;
}
