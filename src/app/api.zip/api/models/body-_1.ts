/* tslint:disable */

/**
 */
export class body_1 {
    user_poll?: number;
    group_guid?: number;
}
