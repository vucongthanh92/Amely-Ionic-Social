/* tslint:disable */

/**
 */
export class PaymentInfo {
    fullname?: string;
    phone?: string;
    address?: string;
    email?: string;
    payment_method?: string;
    note?: string;
}
