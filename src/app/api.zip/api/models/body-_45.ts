/* tslint:disable */

/**
 */
export class body_45 {
    offer_guid?: number;
    counter_offer_guid?: number;
}
