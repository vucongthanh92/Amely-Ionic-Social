/* tslint:disable */

/**
 */
export class body_72 {
    item_guid?: number;
}
