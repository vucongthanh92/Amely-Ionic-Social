/* tslint:disable */

/**
 */
export class body_15 {
    offset?: number;
    limit?: number;
    shop_guid?: number;
    is_shop?: boolean;
    type?: number;
    get_all?: number;
}
