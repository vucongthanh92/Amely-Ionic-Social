/* tslint:disable */

/**
 */
export class body_38 {
    from_guid: number;
    to_guid: number[];
    invitation_type: string;
}
