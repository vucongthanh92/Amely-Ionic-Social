/* tslint:disable */

/**
 */
export class SQ_type {
    filename?: string;
    component?: string;
    classname?: string;
    displayname?: string;
    capacity?: string[];
}
