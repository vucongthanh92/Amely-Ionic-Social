/* tslint:disable */

/**
 */
export class Param_item_temporder {
    guid?: number;
    quantity?: number;
}
