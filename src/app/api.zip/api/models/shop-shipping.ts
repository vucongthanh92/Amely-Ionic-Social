/* tslint:disable */

/**
 */
export class ShopShipping {
    shipping_method?: string;
    guid?: number;
    owner_guid?: string;
    description?: string;
    title?: string;
    type?: string;
    subtype?: string;
    time_created?: string;
    status?: string;
    customer?: string;
    order_guid?: number;
    total_price?: number;
    total_quantity?: number;
    liked?: boolean;
}
