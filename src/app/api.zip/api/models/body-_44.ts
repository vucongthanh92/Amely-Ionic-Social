/* tslint:disable */

/**
 */
export class body_44 {
    offset?: number;
    limit?: number;
    target?: string;
}
