/* tslint:disable */

/**
 */
export class guid {
    guid: number;
}
