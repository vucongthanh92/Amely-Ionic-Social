/* tslint:disable */

/**
 */
export class body_51 {
    friends_hidden: string;
    firstname: string;
    email: string;
    gender: string;
    birthdate: string;
    usercurrency: string;
    lastname: string;
    mobile_hidden?: string;
    birthdate_hidden?: string;
    province?: string;
    district?: string;
    ward?: string;
    address?: string;
}
