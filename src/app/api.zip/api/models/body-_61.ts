/* tslint:disable */

/**
 */
export class body_61 {
    shipping_method?: string;
    shipping_name?: string;
    shipping_phone?: string;
    shipping_address?: string;
    shipping_province?: string;
    shipping_district?: string;
    shipping_ward?: string;
    shipping_note?: string;
    to_guid?: string;
}
