/* tslint:disable */
import { Shipping_methods } from './shipping-_methods';
import { Payment_methods } from './payment-_methods';
import { Options } from './options';

/**
 */
export class inline_response_200_15 {
    shipping_methods?: Shipping_methods;
    payment_methods?: Payment_methods;
    options?: Options;
}
