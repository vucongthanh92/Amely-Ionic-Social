/* tslint:disable */

/**
 */
export class QRCode {
    code?: string;
}
