/* tslint:disable */

/**
 */
export class body_24 {
    shipping_ward?: string;
    step?: string;
    shipping_phone?: string;
    shipping_address?: string;
    shipping_province?: string;
    shipping_district?: string;
    shipping_fullname?: string;
    shipping_note?: string;
    shipping_method?: string;
    shipping_fee?: string;
    item?: string;
    quantity?: number;
    shop_guid?: number;
}
