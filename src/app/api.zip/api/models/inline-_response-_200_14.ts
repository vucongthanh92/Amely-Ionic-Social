/* tslint:disable */

/**
 */
export class inline_response_200_14 {
    url?: string;
}
