/* tslint:disable */

/**
 * Submit properties to be changed
 */
export class body_55 {
    item_guid?: number;
    owner_guid?: number;
    quantity_redeem?: number;
}
