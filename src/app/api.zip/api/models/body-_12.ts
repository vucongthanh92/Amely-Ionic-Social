/* tslint:disable */

/**
 */
export class body_12 {
    items?: string;
}
