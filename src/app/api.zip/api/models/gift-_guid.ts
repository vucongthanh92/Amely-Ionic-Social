/* tslint:disable */

/**
 */
export class gift_guid {
    gift_guid?: number;
}
