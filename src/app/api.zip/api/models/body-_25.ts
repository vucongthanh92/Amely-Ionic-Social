/* tslint:disable */

/**
 */
export class body_25 {
    template?: string;
    title?: string;
    start_date?: string;
    end_date?: string;
    country?: string;
    location?: string;
    description?: string;
    has_inventory?: string;
    status?: string;
    event_type?: string;
    owner_guid?: number;
    members?: string[];
    invites?: string[];
}
