/* tslint:disable */
import { Offer } from './offer';
import { User } from './user';

/**
 */
export class inline_response_200 {
    offer?: Offer[];
    users?: User[];
}
