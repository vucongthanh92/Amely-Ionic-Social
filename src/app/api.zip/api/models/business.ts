/* tslint:disable */
import { User } from './user';

/**
 */
export class Business {
    photo_entity_guid?: string;
    guid?: string;
    description?: string;
    title?: string;
    type?: string;
    subtype?: string;
    category?: string;
    website?: string;
    phone?: string;
    address?: string;
    time_created?: string;
    cover_entity_guid?: string;
    cover_top?: string;
    cover_left?: string;
    avatar?: string;
    cover?: string;
    owner?: User;
    follow?: string;
    followed?: boolean;
    thought?: string;
}
