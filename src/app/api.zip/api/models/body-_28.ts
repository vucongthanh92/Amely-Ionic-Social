/* tslint:disable */

/**
 */
export class body_28 {
    content?: string;
    friends?: string;
    location?: string;
    privacy?: string;
    mood?: string;
    images?: string;
    owner_guid?: number;
    type?: string;
}
