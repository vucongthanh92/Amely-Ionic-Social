/* tslint:disable */

/**
 */
export class body_57 {
    to_guid?: number;
    type?: string;
}
