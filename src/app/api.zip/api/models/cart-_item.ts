/* tslint:disable */
import { Product } from './product';

/**
 */
export class Cart_item {
    products?: Product;
    total?: number;
    tax?: number;
    subtotal?: number;
}
