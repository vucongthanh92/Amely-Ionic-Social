/* tslint:disable */

/**
 */
export class body_26 {
    event_type?: string;
    event_guid?: number;
    offset?: number;
    limit?: number;
}
