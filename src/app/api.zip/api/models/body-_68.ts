/* tslint:disable */

/**
 */
export class body_68 {
    owner_guid?: number;
    cover_type?: string;
    images?: string[];
}
