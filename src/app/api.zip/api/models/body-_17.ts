/* tslint:disable */

/**
 */
export class body_17 {
    new_password?: string;
    email?: string;
}
