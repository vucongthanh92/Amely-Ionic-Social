/* tslint:disable */
import { Feed } from './feed';
import { User } from './user';

/**
 */
export class inline_response_200_8 {
    post?: Feed;
    users?: User[];
}
