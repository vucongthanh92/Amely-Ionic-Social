/* tslint:disable */
import { Product } from './product';
import { Category } from './category';

/**
 */
export class inline_response_200_17 {
    products?: Product[];
    categories?: Category[];
    offset?: number;
}
