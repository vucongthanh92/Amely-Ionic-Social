/* tslint:disable */

/**
 */
export class body_42 {
    owner_type?: string;
    owner_guid?: number;
}
