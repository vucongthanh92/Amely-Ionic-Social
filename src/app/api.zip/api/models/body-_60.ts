/* tslint:disable */

/**
 */
export class body_60 {
    share_type?: string;
    subject_guid?: number;
    post?: string;
}
