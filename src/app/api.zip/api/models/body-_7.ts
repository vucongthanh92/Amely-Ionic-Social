/* tslint:disable */

/**
 */
export class body_7 {
    owner_guid?: number;
    bookmark_type?: string;
    offset?: number;
    limit?: number;
}
