/* tslint:disable */

/**
 */
export class Cart {
}
