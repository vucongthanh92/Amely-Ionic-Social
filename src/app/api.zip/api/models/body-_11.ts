/* tslint:disable */

/**
 */
export class body_11 {
    guid?: number;
    quantity?: number;
}
