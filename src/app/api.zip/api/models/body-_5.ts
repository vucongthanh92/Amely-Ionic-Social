/* tslint:disable */

/**
 */
export class body_5 {
    user_guid?: number;
}
