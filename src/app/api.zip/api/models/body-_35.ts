/* tslint:disable */

/**
 */
export class body_35 {
    name: string;
    description: string;
    privacy: string;
    member_invite: string;
    membership: string;
    has_inventory?: string;
    members: number[];
}
