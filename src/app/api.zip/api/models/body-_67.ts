/* tslint:disable */

/**
 */
export class body_67 {
    owner_guid?: number;
    avatar_type?: string;
    images?: string[];
}
