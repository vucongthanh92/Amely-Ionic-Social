/* tslint:disable */

/**
 */
export class body_13 {
    guid?: number;
    quantity?: number;
}
