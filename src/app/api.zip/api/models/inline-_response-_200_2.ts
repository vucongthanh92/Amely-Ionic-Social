/* tslint:disable */
import { Cart } from './cart';

/**
 */
export class inline_response_200_2 {
    cart?: Cart[];
}
