/* tslint:disable */
import { Store } from './store';

/**
 */
export class body_66 {
    contact?: string;
    shop_guid?: number;
    address?: string;
    phone?: string;
    introduction?: string;
    policy?: string;
    name?: string;
    shop_province?: string;
    shop_district?: string;
    shop_ward?: string;
    stores?: Store[];
    status?: number;
}
