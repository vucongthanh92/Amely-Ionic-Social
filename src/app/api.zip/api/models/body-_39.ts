/* tslint:disable */

/**
 */
export class body_39 {
    duration?: number;
    item_guid?: number;
}
