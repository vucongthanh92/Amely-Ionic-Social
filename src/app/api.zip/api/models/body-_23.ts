/* tslint:disable */

/**
 */
export class body_23 {
    offset?: number;
    limit?: number;
}
