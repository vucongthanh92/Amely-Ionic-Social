/* tslint:disable */

/**
 */
export class body_20 {
    post_guid: string;
    comment: string;
    images: string;
}
