/* tslint:disable */
import { Delivery_order } from './delivery-_order';
import { Shop } from './shop';

/**
 */
export class inline_response_200_5 {
    dos?: Delivery_order[];
    shops?: Shop[];
}
