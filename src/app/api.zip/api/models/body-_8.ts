/* tslint:disable */

/**
 */
export class body_8 {
    name?: string;
    description?: string;
    category?: string;
    phone?: string;
    address?: string;
    website?: string;
}
