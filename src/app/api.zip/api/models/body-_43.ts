/* tslint:disable */

/**
 */
export class body_43 {
    owner_guid: number;
}
