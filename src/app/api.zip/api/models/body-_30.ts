/* tslint:disable */

/**
 */
export class body_30 {
    post_guid?: number;
    content?: string;
    friends?: string;
    location?: string;
    privacy?: string;
    mood?: string;
    images?: string;
    owner_guid?: number;
    type?: string;
}
