/* tslint:disable */

/**
 */
export class body_41 {
    type: string;
    guid: number;
}
