/* tslint:disable */

/**
 */
export class body_53 {
    shop_guid?: number;
    offset?: number;
    limit?: number;
}
