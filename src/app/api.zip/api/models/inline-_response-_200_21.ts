/* tslint:disable */

/**
 */
export class inline_response_200_21 {
    fee?: number;
}
