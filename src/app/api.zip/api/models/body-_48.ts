/* tslint:disable */

/**
 */
export class body_48 {
    expiry?: number;
    sku?: string;
    title?: string;
    description?: string;
    manufacturer?: string;
    is_special?: number;
    voucher_category?: number;
    ticket_category?: number;
    tax?: number;
    price?: number;
    currency?: string;
    quantity?: number;
    weight?: number;
    product_group?: number;
    featured?: number;
    storage_duration?: string;
    duration?: number;
    begin_day?: string;
    end_day?: string;
    friendly_url?: string;
    origin?: string;
    order?: string;
    status?: string;
    ossn_photo?: string[];
    shop_category?: string[];
    market_category?: string[];
    custom_attribute_keys?: string[];
    custom_attribute_values?: string[];
    images?: string[];
    unit?: string;
    enabled?: string;
}
