/* tslint:disable */
import { Item } from './item';

/**
 */
export class Item_cod {
    items?: Item[][];
}
