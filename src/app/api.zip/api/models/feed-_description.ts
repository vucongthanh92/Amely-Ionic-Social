/* tslint:disable */

/**
 */
export class Feed_description {
    post?: string;
    friend?: string;
    location?: string;
}
