/* tslint:disable */

/**
 */
export class Param_create_order {
    shipping_fullname?: string;
    fullname?: string;
    address?: string;
    province?: string;
    district?: string;
    ward?: string;
    note?: string;
    payment?: string;
    bankcode?: string;
    phone?: string;
    shipping_phone?: string;
    shipping_address?: string;
    shipping_province?: string;
    shipping_district?: string;
    shipping_ward?: string;
    shipping_note?: string;
    shipping_method?: string;
    shipping_fee?: string;
    to_guid?: number;
}
