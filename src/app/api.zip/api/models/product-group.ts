/* tslint:disable */

/**
 */
export class ProductGroup {
    type?: string;
    guid?: number;
    owner_guid?: number;
    description?: string;
    title?: string;
    time_created?: number;
    subtype?: string;
    percent?: number;
    price?: number;
    currency?: string;
    status?: string;
}
