/* tslint:disable */
import { User } from './user';
import { Product } from './product';

/**
 */
export class search_responses {
    user?: User;
    products?: Product[];
}
