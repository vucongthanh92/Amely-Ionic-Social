/* tslint:disable */

/**
 */
export class Category {
    friendly_url?: string;
    guid?: number;
    owner_guid?: number;
    description?: string;
    title?: string;
    type?: string;
    subtype?: string;
    time_created?: number;
    sort_order?: string;
    enabled?: string;
    parent_guid?: string;
    creator_guid?: string;
    total_product?: number;
    logo?: string;
    isParent?: boolean;
}
