/* tslint:disable */
import { Product } from './product';
import { Category } from './category';
import { Shop } from './shop';

/**
 */
export class inline_response_200_16 {
    product?: Product;
    categories?: Category[];
    shop?: Shop;
}
