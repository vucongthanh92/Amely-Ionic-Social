/* tslint:disable */

/**
 */
export class body_6 {
    item_guid?: number;
    bookmark_type?: string;
}
