/* tslint:disable */

/**
 */
export class body_49 {
    category_guid?: number;
    shop_guid?: number;
    type_product?: string;
    product_filter?: number;
    get_all?: number;
    offset?: number;
    limit?: number;
}
