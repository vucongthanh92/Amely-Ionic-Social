/* tslint:disable */
import { Product } from './product';

/**
 */
export class Order_item {
    qty?: string;
    items?: Product;
}
