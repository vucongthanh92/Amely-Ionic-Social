/* tslint:disable */
import { DefaultResponse } from './default-response';

/**
 */
export class inline_response_200_19 {
    result?: DefaultResponse[];
    products?: DefaultResponse[];
}
