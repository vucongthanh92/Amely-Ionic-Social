/* tslint:disable */

/**
 */
export class Wallet {
    guid?: string;
    owner_guid?: string;
    card_number?: string;
    balance?: string;
    currency?: string;
    point?: string;
    accumulated_point?: string;
}
