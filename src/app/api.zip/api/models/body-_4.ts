/* tslint:disable */

/**
 */
export class body_4 {
    username: string;
    password: string;
}
