/* tslint:disable */

/**
 */
export class body_71 {
    note?: string;
    action?: string;
    step?: string;
    payment_method?: string;
    paypal_email?: string;
    amount?: string;
    bank_branch_name?: string;
    bank_name?: string;
    bank_account_name?: string;
    bank_account_number?: string;
    bankcode?: string;
}
