/* tslint:disable */
import { Comment } from './comment';
import { User } from './user';

/**
 */
export class inline_response_200_4 {
    comments?: Comment[];
    users?: User[];
}
