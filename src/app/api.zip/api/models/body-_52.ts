/* tslint:disable */

/**
 */
export class body_52 {
    title?: string;
    description?: string;
    time_start?: string;
    time_end?: string;
    status?: string;
}
