/* tslint:disable */
import { Group } from './group';
import { User } from './user';
import { Event } from './event';

/**
 */
export class inline_response_200_12 {
    groups?: Group[];
    users?: User[];
    events?: Event[];
}
