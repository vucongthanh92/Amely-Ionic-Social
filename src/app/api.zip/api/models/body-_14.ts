/* tslint:disable */

/**
 */
export class body_14 {
    title?: string;
    description?: string;
    friendly_url?: string;
    sort_order?: number;
    enabled?: string;
    parent_guid?: number;
    image?: string;
}
