/* tslint:disable */

/**
 */
export class body_9 {
    owner_guid?: number;
    offset?: number;
    limit?: number;
}
