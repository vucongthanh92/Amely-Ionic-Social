/* tslint:disable */

/**
 */
export class body_70 {
    currency?: string;
}
