/* tslint:disable */

/**
 */
export class Manufacturer {
    guid?: number;
    title?: string;
    description?: string;
    featured?: string;
    logo?: string;
}
