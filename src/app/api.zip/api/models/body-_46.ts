/* tslint:disable */

/**
 */
export class body_46 {
    to_guid?: string;
    product_guid?: string;
    redeem_quantity?: string;
}
