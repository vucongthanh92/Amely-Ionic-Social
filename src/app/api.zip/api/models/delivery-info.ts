/* tslint:disable */

/**
 */
export class DeliveryInfo {
    fullname?: string;
    phone?: string;
    address?: string;
    shipping_method?: string;
    shipping_note?: string;
}
