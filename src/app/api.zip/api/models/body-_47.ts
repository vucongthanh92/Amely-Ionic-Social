/* tslint:disable */

/**
 */
export class body_47 {
    guid?: number;
    status?: number;
}
