/* tslint:disable */

/**
 */
export class Comment {
    id?: number;
    time_created?: number;
    owner_guid?: number;
    subject_guid?: string;
    type?: string;
    content?: string;
    photo?: string;
}
