/* tslint:disable */

/**
 */
export class Payment_methods {
}
