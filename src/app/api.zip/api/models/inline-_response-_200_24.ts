/* tslint:disable */
import { Shop } from './shop';
import { User } from './user';

/**
 */
export class inline_response_200_24 {
    shops?: Shop[];
    owners?: User[];
}
