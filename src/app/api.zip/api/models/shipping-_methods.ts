/* tslint:disable */

/**
 */
export class Shipping_methods {
}
