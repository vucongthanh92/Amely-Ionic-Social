/* tslint:disable */

/**
 */
export class body_33 {
    item_guid: number;
}
