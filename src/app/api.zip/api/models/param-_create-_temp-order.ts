/* tslint:disable */
import { Param_item_temporder } from './param-_item-_temporder';

/**
 */
export class Param_create_TempOrder {
    items?: Param_item_temporder[];
    shipping_method?: string;
    shop_guid?: string;
}
