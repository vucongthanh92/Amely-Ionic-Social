/* tslint:disable */

/**
 */
export class body_40 {
    from_guid?: number;
    to_guid?: number;
    join_type?: string;
}
