/* tslint:disable */

/**
 */
export class Photo {
    permission?: number;
    guid?: number;
    type?: string;
    subtype?: string;
    time_created?: number;
    time_updated?: number;
    owner_guid?: number;
    active?: number;
    id?: number;
    value?: string;
    title?: string;
    description?: string;
}
