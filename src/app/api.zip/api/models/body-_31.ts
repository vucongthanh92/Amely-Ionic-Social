/* tslint:disable */

/**
 */
export class body_31 {
    email?: string;
}
