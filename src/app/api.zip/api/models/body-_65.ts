/* tslint:disable */

/**
 */
export class body_65 {
    shop_guid?: number;
    shipping_filter?: string;
    offset?: number;
    page_limit?: number;
}
