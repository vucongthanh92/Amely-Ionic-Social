/* tslint:disable */

/**
 */
export class body_18 {
    old_password?: string;
    new_password?: string;
    confirm_password?: string;
}
