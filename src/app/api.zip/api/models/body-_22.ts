/* tslint:disable */

/**
 */
export class body_22 {
    offer_guid?: number;
    item_guid?: number;
    quantity?: number;
    note?: string;
}
