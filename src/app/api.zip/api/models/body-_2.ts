/* tslint:disable */

/**
 */
export class body_2 {
    advertise_type?: string;
    offset?: number;
    limit?: number;
}
