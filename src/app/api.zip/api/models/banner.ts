/* tslint:disable */

/**
 */
export class Banner {
    banner_url?: string;
    link?: string;
    guid?: number;
    type?: string;
    shop_guid?: number;
    group_guid?: number;
    shop_owner_guid?: number;
    product_guid?: number;
    event_guid?: number;
    page_guid?: number;
}
