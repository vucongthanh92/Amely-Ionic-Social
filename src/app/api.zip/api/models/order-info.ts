/* tslint:disable */

/**
 */
export class OrderInfo {
    currency?: string;
    without_tax?: number;
    tax?: number;
    total_price?: number;
    process_status?: string;
}
