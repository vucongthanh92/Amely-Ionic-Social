/* tslint:disable */

/**
 */
export class ShopOrder {
    shipping_status?: string;
    guid?: number;
    owner_guid?: number;
    description?: string;
    title?: string;
    type?: string;
    subtype?: string;
    time_created?: string;
    process_status?: string;
    shop_guid?: string;
    currency?: string;
    customer?: string;
    total_price?: string;
    total_quantity?: string;
}
