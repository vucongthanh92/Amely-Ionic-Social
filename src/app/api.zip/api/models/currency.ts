/* tslint:disable */

/**
 */
export class Currency {
    isocode?: string;
    displayName?: string;
    rightSymbol?: string;
    leftSymbol?: string;
    decimals?: string;
    decPoints?: string;
    thousandSeparator?: string;
}
