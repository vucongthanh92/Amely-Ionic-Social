/* tslint:disable */

/**
 */
export class Services {
    current_time?: number;
    limit_offer?: number;
    limit_gift?: number;
}
