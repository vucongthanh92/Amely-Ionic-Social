/* tslint:disable */

/**
 */
export class body_27 {
    location?: string;
    event_guid?: number;
    description?: string;
    start_date?: string;
    end_date?: string;
    country?: string;
    title?: string;
    template?: string;
    has_inventory?: string;
    status?: string;
    event_type?: string;
    owner_guid?: number;
    invites?: string;
}
