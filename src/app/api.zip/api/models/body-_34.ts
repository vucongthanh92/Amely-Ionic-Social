/* tslint:disable */

/**
 */
export class body_34 {
    vote_type?: string;
    group_guid?: number;
}
