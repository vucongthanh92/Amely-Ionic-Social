/* tslint:disable */

/**
 */
export class Bankcode {
    options?: string[];
}
