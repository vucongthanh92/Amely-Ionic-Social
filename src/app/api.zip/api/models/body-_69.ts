/* tslint:disable */

/**
 */
export class body_69 {
    offset?: number;
    limit?: number;
}
