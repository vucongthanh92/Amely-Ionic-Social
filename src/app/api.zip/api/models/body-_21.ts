/* tslint:disable */

/**
 */
export class body_21 {
    mobiles?: string[];
}
