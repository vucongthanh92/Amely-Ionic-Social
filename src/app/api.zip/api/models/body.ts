/* tslint:disable */

/**
 */
export class body {
    username?: string;
    password?: string;
    mobilelogin?: string;
    code?: string;
    email?: string;
}
