/* tslint:disable */

/**
 */
export class body_19 {
    new_phone?: string;
}
