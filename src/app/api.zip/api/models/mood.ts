/* tslint:disable */

/**
 */
export class Mood {
    title?: string;
    mood_icon?: string;
    guid?: number;
}
