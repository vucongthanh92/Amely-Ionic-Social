/* tslint:disable */

/**
 */
export class body_63 {
    owner_address?: string;
    shop_name?: string;
    shop_address?: string;
    shop_bidn?: string;
    adjourn_price?: string;
    friendly_url?: string;
    shipping_method?: string;
    owner_name?: string;
    owner_phone?: string;
    shop_phone?: string;
    owner_ssn?: string;
    ossn_photo?: string;
    approve?: string;
    shop_province?: string;
    shop_district?: string;
    shop_ward?: string;
    owner_province?: string;
    owner_district?: string;
    owner_ward?: string;
}
