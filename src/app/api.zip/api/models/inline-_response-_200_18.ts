/* tslint:disable */
import { DefaultResponse } from './default-response';
import { Product } from './product';

/**
 */
export class inline_response_200_18 {
    result?: DefaultResponse[];
    product?: Product[];
}
