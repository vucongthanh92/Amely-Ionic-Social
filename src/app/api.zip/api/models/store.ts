/* tslint:disable */

/**
 */
export class Store {
    type?: string;
    guid?: number;
    owner_guid?: number;
    description?: string;
    title?: string;
    time_created?: number;
    subtype?: string;
    address?: string;
    phone?: string;
    lat?: number;
    lng?: number;
}
