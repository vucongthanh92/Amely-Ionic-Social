/* tslint:disable */

/**
 */
export class body_62 {
    shop_guid?: number;
    order_filter?: string;
    offset?: number;
    page_limit?: number;
}
