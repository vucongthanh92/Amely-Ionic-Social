/* tslint:disable */

/**
 */
export class ShippingInfo {
    without_tax?: number;
    tax?: number;
    total?: number;
    status?: string;
}
