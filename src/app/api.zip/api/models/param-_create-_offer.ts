/* tslint:disable */

/**
 */
export class Param_create_offer {
    location_lat?: string;
    item_guid?: number;
    random_expiration?: boolean;
    giveaway_approval?: boolean;
    target?: string;
    offer_type?: string;
    location_lng?: string;
    duration?: number;
    note?: string;
    quantity?: number;
    limit_counter?: number;
}
