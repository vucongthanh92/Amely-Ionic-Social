/* tslint:disable */

/**
 * Submit properties to be changed
 * fields required true
 */
export class body_56 {
    username?: string;
    firstname?: string;
    lastname?: string;
    email?: string;
    email_re?: string;
    password?: string;
    password_re?: string;
    mobilelogin?: string;
    birthdate?: string;
    gender?: string;
}
