/* tslint:disable */

/**
 */
export class body_3 {
    invitation_type?: string;
    from_guid?: number;
    to_guid?: number;
}
