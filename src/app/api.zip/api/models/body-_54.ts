/* tslint:disable */

/**
 */
export class body_54 {
    promotion_guid?: number;
    title?: string;
    description?: string;
    time_start?: string;
    time_end?: string;
    status?: string;
}
