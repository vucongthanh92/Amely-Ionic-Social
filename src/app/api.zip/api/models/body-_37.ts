/* tslint:disable */

/**
 */
export class body_37 {
    offset: number;
    limit: number;
    owner_guid: number;
    inventory_type: string;
    item_type: string;
}
