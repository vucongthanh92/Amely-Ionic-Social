/* tslint:disable */
import { DefaultResponse } from './default-response';
import { Group } from './group';
import { User } from './user';

/**
 */
export class inline_response_200_11 {
    result?: DefaultResponse;
    groups?: Group[];
    owners?: User[];
}
