/* tslint:disable */

/**
 */
export class Param_create_gift {
    from_guid?: number;
    from_type?: string;
    to_guid?: number;
    to_type?: string;
    item_guid?: number;
    item_quantity?: number;
    message?: string;
}
