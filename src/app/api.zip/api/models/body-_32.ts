/* tslint:disable */

/**
 */
export class body_32 {
    owner_guid?: number;
    type?: string;
}
