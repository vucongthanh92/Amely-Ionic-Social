/* tslint:disable */
import { Event } from './event';
import { User } from './user';

/**
 */
export class inline_response_200_7 {
    events?: Event[];
    users?: User[];
    token?: string;
    error?: string;
    status?: boolean;
}
