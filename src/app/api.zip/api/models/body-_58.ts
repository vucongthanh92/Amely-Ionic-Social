/* tslint:disable */

/**
 */
export class body_58 {
    report_type?: string;
    guid?: number;
    reason?: string;
}
