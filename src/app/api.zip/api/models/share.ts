/* tslint:disable */
import { Feed } from './feed';
import { Product } from './product';

/**
 */
export class Share {
    posts?: Feed[];
    products?: Product[];
}
