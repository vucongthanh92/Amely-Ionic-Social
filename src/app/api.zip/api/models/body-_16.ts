/* tslint:disable */

/**
 */
export class body_16 {
    category_guid?: number;
    title?: string;
    description?: string;
    friendly_url?: string;
    sort_order?: number;
    enabled?: string;
    parent_guid?: number;
    image?: string;
}
