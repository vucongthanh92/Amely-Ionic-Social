/* tslint:disable */

/**
 */
export class Advertise {
    budget?: number;
    guid?: number;
    owner_guid?: number;
    description?: string;
    title?: string;
    subtype?: string;
    advertise_type?: string;
    link?: string;
    start_date?: string;
    end_date?: string;
    time_created?: string;
    cpc?: number;
    start_time?: string;
    end_time?: string;
    enabled?: string;
    currency?: string;
    admin_created?: string;
    approved?: string;
    amount?: number;
    number_click?: number;
}
