/* tslint:disable */

/**
 */
export class body_36 {
    group_guid: number;
    name: string;
    description: string;
    privacy: string;
    member_invite: string;
    membership: string;
}
