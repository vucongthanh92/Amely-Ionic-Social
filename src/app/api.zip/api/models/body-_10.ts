/* tslint:disable */

/**
 */
export class body_10 {
    business_guid?: number;
    name?: string;
    description?: string;
    category?: string;
    phone?: string;
    address?: string;
    website?: string;
}
