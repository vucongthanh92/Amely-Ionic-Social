/* tslint:disable */
import { Payment_methods } from './payment-_methods';
import { Bankcode } from './bankcode';

/**
 */
export class inline_response_200_25 {
    limit?: {};
    payment_method?: Payment_methods;
    url?: string;
    status?: boolean;
    bankcode?: Bankcode;
}
