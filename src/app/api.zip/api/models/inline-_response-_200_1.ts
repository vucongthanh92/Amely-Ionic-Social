/* tslint:disable */
import { Business } from './business';
import { User } from './user';

/**
 */
export class inline_response_200_1 {
    pages?: Business[];
    users?: User[];
}
