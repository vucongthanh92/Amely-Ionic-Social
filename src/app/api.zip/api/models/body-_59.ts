/* tslint:disable */

/**
 */
export class body_59 {
    mobile?: string;
    text_search?: string;
    category?: string;
    type?: string;
}
