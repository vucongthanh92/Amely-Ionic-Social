/* tslint:disable */
import { Cart_item } from './cart-_item';

/**
 */
export class inline_response_200_3 {
    cart?: Cart_item[];
    status?: boolean;
}
