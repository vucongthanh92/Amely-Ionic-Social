/* tslint:disable */

/**
 */
export class inline_response_200_13 {
    offer_guid?: number;
}
